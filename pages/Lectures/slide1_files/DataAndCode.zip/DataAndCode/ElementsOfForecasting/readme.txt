These data and Eviews programs replicate many of the results in the text.  
Occasional divergences occur between the output from the programs and the results
reported in the text, due primarily to:

(1) Different sample periods
(2) Different conventions for calculating AIC and SIC in Eviews 5 and Eviews 4 (which was used
for most of the text)
(3) Different numerical optimization algorithms in Eviews 5 and Eviews 4.

fcst*.prg files are Eviews batch programs, which will typically use the data in the fcst*input.wf1 
Eview workfile. (The same dataset in ASCII format is provided by the fcst*input.dat files.) 
To run a program, open the *.prg file in Eviews and click 'RUN' on the program toolbar.  
Be sure to modify the data file's pathname if necessary. The result you obtain should look similiar
to what you see in the Eview workfile fcst*finalized.wf1.

We also include data files used in the Exercises, Problems and Complements.  The data
files are named *.dat, and are in ASCII format.   

The following is a brief description of each data set:

\FCST4-02\fcst2input.dat          - x, y, z -  48 observations.
\FCST4-02\PC2_7_xyz.dat           - x, y, z -  45 observations.

\FCST4-04\fcst4anscombeinput.dat  - x1-4, y1-4, 11 observations.
\FCST4-04\fcst4gdp.dat            - agriculture, manufacturing, retail, services, 1960-2001 (42 observations)
\FCST4-04\fcst4intestinput.dat    - 1 year, 10 year, 20 year and 30 year treasury bond rates, 1953:4 - 2005:3 (624 observations)
\FCST4-04\PC4_06_exchrate.dat     - Hungarian exchange rate, 620 observations.
\FCST4-04\PC4_10_earnings.dat     - current earnings and one lagged variable (82 observations)

\FCST4-05\fcst5input.dat          - retail sales, 1954:1-1995:1 (493 observations);  
                                    and NYSE volume, 1900:1-2005:4 (1264 observations)
\FCST4-05\PC5_07_eurostar.dat     - eurostar, 24 observations

\FCST4-06\fcst6input.dat          - housing starts 1946:01-1994:11 (587 observations) 
\FCST4-06\PC6_06_web.dat          - web hits, 271 observations

\FCST4-07\fcst7input.dat          - Canadian employment index, seasonally adjusted, 1961:1-1994:4 (136
observations) 

\FCST4-08\fcst8input.dat          - Canadian employment index, seasonally adjusted, 1961:1-1994:4 (136
observations) 
\FCST4-08\PC8_6_BankWire.dat      - bank transfers, 200 observations

\FCST4-09\fcst9input.dat          - Canadian employment index, seasonally adjusted, 1961:1-1994:4 (136
observations) 
\FCST4-09\PC9_2_BankWire.dat      - bank transfers, 200 observations
\FCST4-09\PC9_07_web.dat          - web hits, 271 observations

\FCST4-10\fcst10input.dat         - liquor sales 1967:01-1994:12 (336 observations) 
\FCST4-10\PC10_06_airspeed.dat    - AirSpeed, 64 observations.

\FCST4-11\fcst11input.dat         - date, starts, completions, 1968:01-1996:06 (342 observations) 

\FCST4-12\fcst12input.dat         - vol, volq, volj, 1/01/1988-7/18/1997 (weekly, 499 observations) 
\FCST4-12\PC12_02.dat             - 1 quarter-ahead - 4 quarters-ahead forecast errors, 80 observations

\FCST4-13\fcst13input.dat         - date, yen/$, 1973:01-1996:07 (283 observations)
\FCST4-13\PC13_01_exch.dat        - date, yen/$, DM/$, 1973:01-1996:07 (283 observations)

\FCST4-14\fcst14input.dat         - daily observations of NYSE returns (3531 observations)




